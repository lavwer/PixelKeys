plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pixelkeys"
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileSdk = 34

    defaultConfig {
        applicationId = "com.pixelkeys.keyboard"
        minSdk = 29
        targetSdk = 34
        versionCode = 12
        versionName = "3.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
// Сторонних библиотек нет вообще: только то, что есть в самом Android.
