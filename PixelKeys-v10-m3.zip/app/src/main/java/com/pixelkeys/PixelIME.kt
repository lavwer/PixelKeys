package com.pixelkeys

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class PixelIME : InputMethodService() {

    private val ruRows = listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
    private val enRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val sym1 = listOf("@#\$_&-+()/", "*\"':;!?,.%", "~|\\<>[]")
    private val sym2 = listOf("€£¥¢°•×÷±¶", "{}^`«»§√π=", "™©®∞≈≠≤")
    // Долгое нажатие: показывает мелкую подсказку в углу клавиши и вводит этот символ
    private val ALT = mapOf("е" to "ё", "ь" to "ъ", "." to "?", "," to "!")

    // Эмодзи по категориям (первый символ категории служит значком вкладки)
    private val emojiCats = listOf(
        "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕",
        "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💪 👀 👅 👄 🧠 👶 👦 👧 👨 👩 🧑 👴 👵 🙋 🤷 🤦 💁 🙆 🙅 💃 🕺",
        "❤️ 🧡 💛 💚 💙 💜 🖤 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 🔥 ✨ ⭐ 🌟 ⚡ ✅ ❌ ❓ ❗ ⚠️ 🚫 ♻️ 🔞 ➕ ➖ ➗ ✖️ 💲",
        "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🦈 🐊 🌵 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🌸 🌹 🌻 🌼 🌞 🌙 🌈 ☁️ ❄️ 🌊",
        "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🍍 🥝 🍅 🥑 🥦 🥕 🌽 🍞 🧀 🍳 🥞 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍝 🍜 🍲 🍣 🍤 🍦 🍩 🍪 🎂 🍰 🍫 🍬 🍭 ☕ 🍵 🥛 🍺 🍻 🥂 🍷 🍸 🍹",
        "⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎯 🎮 🎲 🎵 🎶 🎤 🎧 🎸 🎹 🎬 📷 📱 💻 ⌨️ 🖥 🎁 🎉 🎊 🏆 🥇 🚗 🚕 🚌 🚓 🚑 ✈️ 🚀 🚲 🏠 🏢 ⏰ 📌 📎 ✏️ 📚 💡 🔑 🔒 💰 💳"
    ).map { it.split(" ") }

    private lateinit var pal: Palette
    private lateinit var store: ClipStore
    private lateinit var cm: ClipboardManager
    private val dict = Dict()
    private val corr = Corrector(dict)
    private val mainH = Handler(Looper.getMainLooper())
    private val sugRun = Runnable { doSuggestions() }
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    private var lang = 0      // 0 = русский, 1 = английский
    private var page = 0      // 0 = буквы, 1 = символы 1, 2 = символы 2
    private var shift = 0     // 0 = выкл, 1 = на одну букву, 2 = Caps Lock
    private var lastShiftTap = 0L
    private var lastSpace = 0L
    private var mode = 0      // 0 = клавиши, 1 = буфер, 2 = эмодзи
    private var emojiCat = 0
    private var themeMode = 0
    private var heightMode = 1
    private var showPunct = true
    private var t9On = true
    private var numMode = 1        // ряд цифр: 0 = всегда, 1 = только вертикально, 2 = скрыть
    private var minimal = false    // режим «только буквы»
    private var keyRows = 5
    private var builtLandscape = false
    private var builtNight = false
    private var builtSig = ""
    private var bgBmp: Bitmap? = null
    private var navColor = 0
    private var contentBox: FrameLayout? = null
    private var curWord = ""
    private var autoOn = true
    private var autoAny = true        // автоисправление и там, где приложение просит «без подсказок»
    private val localWord = StringBuilder()   // слово, которое мы сами набрали (на случай, если приложение отдаёт текст с задержкой)
    private var sugDelLen = 0
    private var sugKey = ""                         // для кэша подсказок: одно и то же состояние не считаем дважды
    private var sugCache: List<String> = emptyList()
    private var sugDelCache = 0
    private class Corr(val original: String, val corrected: String, val sep: String)
    private var lastCorr: Corr? = null

    private var keysBox: LinearLayout? = null
    private var clipScroll: ScrollView? = null
    private var clipList: LinearLayout? = null
    private var emojiBox: LinearLayout? = null
    private var emojiTop: LinearLayout? = null
    private var emojiGrid: LinearLayout? = null
    private var clipBtn: Key? = null
    private var emojiBtn: Key? = null
    private var clearBtn: Key? = null
    private var titleView: TextView? = null
    private var sugBox: LinearLayout? = null
    private val sugViews = mutableListOf<TextView>()
    private val sugText = arrayOfNulls<String>(3)
    private var shiftKey: Key? = null
    private var enterKey: Key? = null
    private val letterKeys = mutableListOf<Key>()

    // ---------- жизненный цикл ----------

    override fun onCreate() {
        super.onCreate()
        loadPrefs()
        pal = Palette(this, themeMode)
        store = ClipStore(this)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        Thread { dict.load(assets) }.start()   // словари грузятся в фоне
    }

    override fun onDestroy() {
        cm.removePrimaryClipChangedListener(clipListener)
        mainH.removeCallbacks(sugRun)
        super.onDestroy()
    }

    private fun loadPrefs() {
        val sp = getSharedPreferences("ui", Context.MODE_PRIVATE)
        themeMode = sp.getInt("theme", 0)
        heightMode = sp.getInt("height", 1)
        showPunct = sp.getInt("punct", 0) == 0
        t9On = sp.getInt("t9", 0) == 0
        autoOn = sp.getInt("autocorr", 0) == 0
        autoAny = sp.getInt("autoany", 0) == 0
        numMode = sp.getInt("numrow", 1)
        minimal = sp.getInt("minimal", 0) == 1
    }

    override fun onEvaluateFullscreenMode() = false

    private fun loadUserWords() {
        val set = getSharedPreferences("ui", Context.MODE_PRIVATE).getStringSet("userwords", null)
        dict.user.clear()
        if (set != null) dict.user.addAll(set)
    }

    private fun learnWord(w: String) {
        if (w.length < 2 || w.length > 40 || dict.user.size >= 1000) return
        dict.user.add(w)
        getSharedPreferences("ui", Context.MODE_PRIVATE).edit().putStringSet("userwords", HashSet(dict.user)).apply()
    }

    // Поворот экрана / смена день-ночь: пересобираем клавиатуру под новые размеры
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val land = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
        val night = (newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (land != builtLandscape || night != builtNight) {
            loadPrefs()
            pal = Palette(this, themeMode)
            setInputView(buildRoot())
            afterInput()
            styleNavBar()
        }
    }

    override fun onCreateInputView(): View {
        loadPrefs()
        pal = Palette(this, themeMode)
        return buildRoot()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val sp = getSharedPreferences("ui", Context.MODE_PRIVATE)
        val rebuild = Palette.signature(this) != builtSig
        loadPrefs()
        loadUserWords()
        localWord.setLength(0)
        sugKey = ""
        recordDiag(info)
        if (rebuild) {
            pal = Palette(this, themeMode)
            setInputView(buildRoot())
        }
        if (mode != 0) setMode(0)
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        page = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 1 else 0
        shift = 0
        renderKeys()
        afterInput()
        styleNavBar()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateSuggestions()
    }

    @Suppress("DEPRECATION")
    private fun styleNavBar() {
        val w = window?.window ?: return
        w.navigationBarColor = if (navColor != 0) navColor else pal.bg
        val v = w.decorView
        v.systemUiVisibility = if (pal.night) {
            v.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        } else {
            v.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    // ---------- построение интерфейса ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun isLandscape() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun systemNight() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private fun barH() = if (isLandscape()) dp(34) else dp(40)
    private fun showNumRowOnLetters() = !minimal && (numMode == 0 || (numMode == 1 && !isLandscape()))

    private fun applyContentHeight() {
        val c = contentBox ?: return
        val rows = if (mode == 0) keyRows else 5
        val h = rowH() * rows
        val lp = c.layoutParams
        if (lp != null && lp.height != h) {
            lp.height = h
            c.layoutParams = lp
        }
    }

    private fun rowH(): Int {
        val base = if (isLandscape()) 34 else 46
        val scale = when (heightMode) {
            0 -> 0.88f
            2 -> 1.15f
            else -> 1f
        }
        return dp((base * scale).toInt())
    }

    private fun ico(id: Int): Drawable? = getDrawable(id)?.mutate()

    private fun buildRoot(): View {
        mode = 0
        builtLandscape = isLandscape()
        builtNight = systemNight()
        builtSig = Palette.signature(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val photo = if (pal.hasPhoto) BgStore.load(this) else null
        bgBmp = photo
        if (photo != null) {
            root.background = CropDrawable(photo)
            navColor = BgStore.bottomColor(photo)
        } else {
            root.setBackgroundColor(pal.bg)
            navColor = pal.bg
        }
        root.setPadding(dp(pal.hpadDp), dp(4), dp(pal.hpadDp), dp(pal.bpadDp))

        // верхняя панель: буфер, эмодзи, капсула с T9, запуск приложения
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL

        val cb = Key(this, pal, Key.FLAT).apply {
            icon = ico(R.drawable.ic_clipboard)
            onTap = { setMode(1) }
        }
        clipBtn = cb
        bar.addView(cb, LinearLayout.LayoutParams(dp(48), barH()))

        val emb = Key(this, pal, Key.FLAT).apply {
            icon = ico(R.drawable.ic_emoji)
            onTap = { setMode(2) }
        }
        emojiBtn = emb
        bar.addView(emb, LinearLayout.LayoutParams(dp(48), barH()))

        // капсула
        val capsule = LinearLayout(this)
        capsule.orientation = LinearLayout.HORIZONTAL
        capsule.gravity = Gravity.CENTER_VERTICAL
        val capBg = GradientDrawable()
        capBg.setColor(pal.keyA)
        capBg.cornerRadius = dp(20).toFloat()
        capsule.background = capBg
        capsule.setPadding(dp(6), 0, dp(6), 0)

        // три подсказки T9
        val sb = LinearLayout(this)
        sb.orientation = LinearLayout.HORIZONTAL
        sb.gravity = Gravity.CENTER_VERTICAL
        sugViews.clear()
        for (i in 0 until 3) {
            val t = TextView(this)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.setAutoSizeTextTypeUniformWithConfiguration(11, 16, 1, TypedValue.COMPLEX_UNIT_SP)
            t.setTextColor(pal.text)
            t.setPadding(dp(4), 0, dp(4), 0)
            t.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                sugTap(i)
            }
            sb.addView(t, LinearLayout.LayoutParams(0, MATCH, 1f))
            sugViews.add(t)
            if (i < 2) {
                val dv = View(this)
                dv.setBackgroundColor(pal.pressed)
                sb.addView(dv, LinearLayout.LayoutParams(dp(1), dp(16)))
            }
        }
        sugBox = sb
        capsule.addView(sb, LinearLayout.LayoutParams(0, MATCH, 1f))

        // в панелях буфера/эмодзи капсула показывает заголовок
        val tv = TextView(this)
        tv.setTextColor(pal.text)
        tv.textSize = 15f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(10), 0, 0, 0)
        tv.visibility = View.GONE
        titleView = tv
        capsule.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))

        val cl = Key(this, pal, Key.FLAT).apply {
            label = "Очистить"
            textSp = 14f
            visibility = View.GONE
            onTap = {
                store.clearUnpinned()
                refreshClips()
            }
        }
        clearBtn = cl
        capsule.addView(cl, LinearLayout.LayoutParams(dp(92), MATCH))

        val capLp = LinearLayout.LayoutParams(0, barH() - dp(6), 1f)
        capLp.setMargins(dp(4), 0, dp(4), 0)
        bar.addView(capsule, capLp)

        // самая правая кнопка: открыть приложение Pixel Keys
        val ab = Key(this, pal, Key.FLAT).apply {
            icon = ico(R.drawable.ic_app)
            onTap = { openApp() }
        }
        bar.addView(ab, LinearLayout.LayoutParams(dp(48), barH()))

        // область под панелью: клавиши, буфер или эмодзи
        val content = FrameLayout(this)
        contentBox = content
        val kb = LinearLayout(this)
        kb.orientation = LinearLayout.VERTICAL
        keysBox = kb

        val sv = ScrollView(this)
        sv.visibility = View.GONE
        sv.isVerticalScrollBarEnabled = false
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list)
        clipScroll = sv
        clipList = list

        val ebox = LinearLayout(this)
        ebox.orientation = LinearLayout.VERTICAL
        ebox.visibility = View.GONE
        val etop = LinearLayout(this)
        etop.orientation = LinearLayout.HORIZONTAL
        val esv = ScrollView(this)
        esv.isVerticalScrollBarEnabled = false
        val egrid = LinearLayout(this)
        egrid.orientation = LinearLayout.VERTICAL
        esv.addView(egrid)
        ebox.addView(etop, LinearLayout.LayoutParams(MATCH, rowH()))
        ebox.addView(esv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        emojiBox = ebox
        emojiTop = etop
        emojiGrid = egrid

        content.addView(kb, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(ebox, FrameLayout.LayoutParams(MATCH, MATCH))

        root.addView(bar, LinearLayout.LayoutParams(MATCH, barH()))
        root.addView(content, LinearLayout.LayoutParams(MATCH, rowH() * 5))
        renderKeys()
        return root
    }

    private fun openApp() {
        try {
            val i = Intent(this, SettingsActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            requestHideSelf(0)
        } catch (e: Exception) {
        }
    }

    private fun addRow(box: LinearLayout, keys: List<Key>, target: Float) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        var sum = 0f
        for (k in keys) sum += k.weight
        val pad = (target - sum) / 2f
        if (pad > 0.01f) r.addView(View(this), LinearLayout.LayoutParams(0, MATCH, pad))
        for (k in keys) r.addView(k, LinearLayout.LayoutParams(0, MATCH, k.weight))
        if (pad > 0.01f) r.addView(View(this), LinearLayout.LayoutParams(0, MATCH, pad))
        box.addView(r, LinearLayout.LayoutParams(MATCH, rowH()))
    }

    private fun charKey(ch: String, letter: Boolean, sp: Float = 22f, kind: Int = 0): Key {
        val k = Key(this, pal, kind)
        k.textSp = sp
        k.tag = ch
        k.preview = true
        k.label = if (letter) shifted(ch) else ch
        val alt = ALT[ch]
        if (alt != null) {
            k.hint = if (letter) shifted(alt) else alt
            k.onLong = { type(if (letter) shifted(alt) else alt) }
        }
        k.onTap = { type(if (letter) shifted(ch) else ch) }
        if (letter) letterKeys.add(k)
        return k
    }

    private fun backKey(w: Float) = Key(this, pal, Key.SPECIAL).apply {
        weight = w
        scallop = true
        icon = ico(R.drawable.ic_backspace)
        repeatable = true
        onTap = { backspace() }
    }

    private fun showPicker() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun switchLang() {
        lang = 1 - lang
        page = 0
        renderKeys()
    }

    private fun renderKeys() {
        val box = keysBox ?: return
        box.removeAllViews()
        letterKeys.clear()
        shiftKey = null
        val ru = lang == 0
        val rows = if (ru) ruRows else enRows
        val tgt = if (page == 0) rows[0].length.toFloat() else 10f
        var count = 0

        // ряд цифр: на страницах цифр/символов он нужен всегда, на буквенной — по настройке
        if (page != 0 || showNumRowOnLetters()) {
            addRow(box, "1234567890".map { charKey(it.toString(), false, 18f) }, 10f)
            count++
        }

        if (page == 0) {
            addRow(box, rows[0].map { charKey(it.toString(), true) }, tgt)
            addRow(box, rows[1].map { charKey(it.toString(), true) }, tgt)
            val sw = (tgt - rows[2].length) / 2f
            val sk = Key(this, pal, Key.SPECIAL).apply {
                weight = sw
                onTap = { onShift() }
            }
            shiftKey = sk
            addRow(box, listOf(sk) + rows[2].map { charKey(it.toString(), true) } + backKey(sw), tgt)
        } else {
            val s = if (page == 1) sym1 else sym2
            addRow(box, s[0].map { charKey(it.toString(), false) }, 10f)
            addRow(box, s[1].map { charKey(it.toString(), false) }, 10f)
            val tk = Key(this, pal, Key.SPECIAL).apply {
                weight = 1.5f
                textSp = 15f
                label = if (page == 1) "=\\<" else "?123"
                onTap = {
                    page = if (page == 1) 2 else 1
                    renderKeys()
                }
            }
            addRow(box, listOf(tk) + s[2].map { charKey(it.toString(), false) } + backKey(1.5f), 10f)
        }
        count += 3

        // нижний ряд. Без запятой и точки кнопки шире; в режиме «только буквы» остаются «…», пробел и Enter
        val withPunct = showPunct && !minimal
        val symW = if (withPunct) 1.5f else 1.75f
        val enterW = symW
        val globeW = if (minimal) 0f else if (withPunct) 1f else 1.5f
        val punctW = if (withPunct) 2f else 0f

        val sym = Key(this, pal, Key.SPECIAL).apply {
            weight = symW
            textSp = if (minimal && page == 0) 22f else 15f
            label = if (page == 0) { if (minimal) "…" else "?123" } else if (ru) "АБВ" else "ABC"
            onTap = {
                page = if (page == 0) 1 else 0
                renderKeys()
            }
            if (minimal) onLong = { showPicker() }
        }
        val globe = Key(this, pal, Key.SPECIAL).apply {
            weight = globeW
            scallop = true
            icon = ico(R.drawable.ic_globe)
            onTap = { switchLang() }
            onLong = { showPicker() }
        }
        val space = Key(this, pal).apply {
            weight = tgt - (symW + enterW + globeW + punctW)
            textSp = 13f
            label = if (ru) "Русский" else "English"
            onTap = { type(" ") }
            if (minimal) onLong = { switchLang() }   // без глобуса язык меняется долгим нажатием на пробел
        }
        val ek = Key(this, pal, Key.ACTION).apply {
            scallop = true
            weight = enterW
            textSp = 14f
            onTap = { enter() }
        }
        enterKey = ek

        val bottom = ArrayList<Key>()
        bottom.add(sym)
        if (withPunct) bottom.add(charKey(",", false, 22f, Key.SPECIAL))
        if (!minimal) bottom.add(globe)
        bottom.add(space)
        if (withPunct) bottom.add(charKey(".", false, 22f, Key.SPECIAL))
        bottom.add(ek)
        addRow(box, bottom, tgt)
        count++

        keyRows = count
        applyContentHeight()
        applyShift()
        updateEnter()
    }

    // ---------- панели: буфер и эмодзи ----------

    private fun setMode(m: Int) {
        mode = if (mode == m) 0 else m   // повторное нажатие закрывает панель
        applyContentHeight()
        keysBox?.visibility = if (mode == 0) View.VISIBLE else View.GONE
        clipScroll?.visibility = if (mode == 1) View.VISIBLE else View.GONE
        emojiBox?.visibility = if (mode == 2) View.VISIBLE else View.GONE
        clipBtn?.active = mode == 1
        emojiBtn?.active = mode == 2
        sugBox?.visibility = if (mode == 0) View.VISIBLE else View.GONE
        titleView?.visibility = if (mode == 0) View.GONE else View.VISIBLE
        clearBtn?.visibility = if (mode == 1) View.VISIBLE else View.GONE
        titleView?.text = when (mode) {
            1 -> "Буфер обмена"
            2 -> "Эмодзи"
            else -> ""
        }
        if (mode == 1) refreshClips()
        if (mode == 2) renderEmoji()
        if (mode == 0) updateSuggestions()
    }

    private fun renderEmoji() {
        val top = emojiTop ?: return
        val grid = emojiGrid ?: return
        top.removeAllViews()
        grid.removeAllViews()

        val back = Key(this, pal, Key.SPECIAL).apply {
            weight = 1.4f
            textSp = 14f
            label = if (lang == 0) "АБВ" else "ABC"
            onTap = { setMode(0) }
        }
        top.addView(back, LinearLayout.LayoutParams(0, MATCH, back.weight))
        for (i in emojiCats.indices) {
            val tab = Key(this, pal, Key.FLAT).apply {
                textSp = 20f
                haptic = false
                label = emojiCats[i][0]
                active = i == emojiCat
                onTap = {
                    emojiCat = i
                    renderEmoji()
                }
            }
            top.addView(tab, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        val del = backKey(1.4f)
        top.addView(del, LinearLayout.LayoutParams(0, MATCH, del.weight))

        val items = emojiCats[emojiCat]
        val perRow = 8
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val end = minOf(i + perRow, items.size)
            for (j in i until end) {
                val e = items[j]
                val k = Key(this, pal, Key.FLAT).apply {
                    textSp = 24f
                    label = e
                    haptic = false
                    onTap = { currentInputConnection?.commitText(e, 1) }
                }
                row.addView(k, LinearLayout.LayoutParams(0, MATCH, 1f))
            }
            val missing = perRow - (end - i)
            if (missing > 0) row.addView(View(this), LinearLayout.LayoutParams(0, MATCH, missing.toFloat()))
            grid.addView(row, LinearLayout.LayoutParams(MATCH, rowH()))
            i += perRow
        }
    }

    // ---------- T9: подсказки слов ----------

    private fun updateSuggestions() {
        mainH.removeCallbacks(sugRun)
        mainH.post(sugRun)
        mainH.postDelayed(sugRun, 90)    // повтор: некоторые приложения обновляют текст не сразу
    }

    /** Слово слева от курсора. Если приложение отстаёт на 1–2 буквы, дополняем тем, что набрали сами. */
    private fun resolveWord(before: String): String {
        val ed = trailingWord(before)
        val loc = localWord.toString()
        if (loc.isEmpty() || ed == loc) return ed
        if (ed.isNotEmpty() && loc.startsWith(ed) && loc.length - ed.length <= 2) return loc
        localWord.setLength(0)   // курсор перенесли или текст изменили — доверяем приложению
        return ed
    }

    private fun badVariation(t: Int): Boolean {
        val v = t and InputType.TYPE_MASK_VARIATION
        return v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_URI
    }

    /** T9 работает почти везде. Выключен только в полях паролей, почты, адресов, чисел и телефонов.
     *  Пометку приложения «без подсказок» игнорируем (подсказки ничего не меняют в тексте). */
    private fun whyNoT9(ei: EditorInfo): String? {
        val t = ei.inputType
        val cls = t and InputType.TYPE_MASK_CLASS
        if (cls != InputType.TYPE_CLASS_TEXT && cls != 0) return "числовое или особое поле"
        if (cls == InputType.TYPE_CLASS_TEXT && badVariation(t)) return "пароль, почта или адрес"
        return null
    }

    private fun whyNoAuto(ei: EditorInfo): String? {
        val t = ei.inputType
        val cls = t and InputType.TYPE_MASK_CLASS
        if (cls != InputType.TYPE_CLASS_TEXT && cls != 0) return "числовое или особое поле"
        if (cls == InputType.TYPE_CLASS_TEXT) {
            if (badVariation(t)) return "пароль, почта или адрес"
            val v = t and InputType.TYPE_MASK_VARIATION
            if (v == InputType.TYPE_TEXT_VARIATION_PERSON_NAME) return "поле имени"
            if (v == InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS) return "поле адреса"
            if (!autoAny && (t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return "приложение запретило подсказки"
        }
        return null
    }

    private fun t9Allowed(ei: EditorInfo) = whyNoT9(ei) == null

    /** Запоминаем (только на телефоне), в каких приложениях что работает: это видно в приложении Pixel Keys. */
    private fun recordDiag(ei: EditorInfo?) {
        if (ei == null) return
        val pkg = ei.packageName ?: "?"
        val line = pkg + " | T9: " + (whyNoT9(ei) ?: "работает") + " | авто: " + (whyNoAuto(ei) ?: "работает") +
            " | inputType=0x" + Integer.toHexString(ei.inputType)
        val sp = getSharedPreferences("ui", Context.MODE_PRIVATE)
        val old = (sp.getString("diag", "") ?: "").split("\n").filter { it.isNotBlank() && !it.startsWith("$pkg |") }
        sp.edit().putString("diag", (listOf(line) + old).take(8).joinToString("\n")).apply()
    }

    /** Автоисправление меняет текст, поэтому уважает пометку приложения «без подсказок» и не трогает имена и адреса. */
    private fun acAllowed(ei: EditorInfo) = whyNoAuto(ei) == null

    private fun trailingWord(s: String): String {
        var i = s.length
        while (i > 0 && s[i - 1].isLetter()) i--
        if (i > 0 && (s[i - 1] == '\'' || s[i - 1] == '’')) return ""
        return s.substring(i)
    }

    /** Последний «кусок» текста: латиница вместе с , . ; ' [ ] ` (это буквы б ю ж э х ъ ё на русской раскладке) или кириллица. */
    private fun trailingToken(s: String): String {
        var i = s.length
        if (i == 0) return ""
        val last = s[i - 1]
        if (Layout.isLatinTokenChar(last)) {
            while (i > 0 && Layout.isLatinTokenChar(s[i - 1])) i--
        } else if (Layout.isCyr(last)) {
            while (i > 0 && Layout.isCyr(s[i - 1])) i--
        } else {
            return ""
        }
        return s.substring(i)
    }

    private fun matchCase(typed: String, s: String): String {
        if (typed.length > 1 && typed.all { it.isUpperCase() }) return s.uppercase()
        if (typed[0].isUpperCase()) return s.replaceFirstChar { it.uppercase() }
        return s
    }

    private fun doSuggestions() {
        if (sugViews.size < 3) return
        val ei = currentInputEditorInfo
        val enabled = t9On && mode == 0 && ei != null && t9Allowed(ei) && currentInputConnection != null
        var word = ""
        var list: List<String> = emptyList()
        sugDelLen = 0
        if (enabled) {
            val before = currentInputConnection?.getTextBeforeCursor(60, 0)?.toString() ?: ""
            word = resolveWord(before)
            val key = before + "\u0001" + word + "\u0001" + dict.ready() + dict.user.size + pal.lite
            if (key == sugKey) {
                list = sugCache
                sugDelLen = sugDelCache
            } else {
            sugDelLen = word.length
            if (word.isNotEmpty()) {
                val cyr = Layout.isCyr(word[0])
                list = dict.suggest(if (cyr) 0 else 1, word, 3).map { matchCase(word, it) }
                if (list.isEmpty() && word.length >= 3 && !pal.lite) {
                    // слово с опечаткой: предлагаем варианты исправления
                    val low = word.lowercase()
                    val lg = if (cyr) 0 else 1
                    if (dict.ready() && !dict.known(lg, low)) {
                        list = corr.candidates(low, lg, 3).map { matchCase(word, it) }
                    }
                }
                if (list.isEmpty()) {
                    // возможно, слово набрано не в той раскладке
                    val tok = trailingToken(before)
                    if (tok.length >= 2) {
                        val latin = Layout.isLatinTokenChar(tok[tok.length - 1])
                        val mapped = if (latin) Layout.toRu(tok.lowercase()) else Layout.toEn(tok.lowercase())
                        val okMapped = if (latin) mapped.all { Layout.isCyr(it) } else mapped.all { it in 'a'..'z' }
                        if (okMapped) {
                            val alt = dict.suggest(if (latin) 0 else 1, mapped, 3, true)
                            if (alt.isNotEmpty()) {
                                list = alt.map { matchCase(tok, it) }
                                sugDelLen = tok.length
                            }
                        }
                    }
                }
            }
            sugKey = key
            sugCache = list
            sugDelCache = sugDelLen
            }
        }
        curWord = word
        val placeholder = enabled && word.isEmpty()
        for (i in 0 until 3) {
            val s = if (i < list.size) list[i] else null
            sugText[i] = s
            val tv = sugViews[i]
            if (placeholder && i == 1) {
                tv.text = "T9"
                tv.setTextColor(pal.hint)
            } else {
                tv.text = s ?: ""
                tv.setTextColor(pal.text)
            }
        }
    }

    private fun sugTap(i: Int) {
        val s = sugText[i] ?: return
        pickSuggestion(s)
    }

    private fun pickSuggestion(s: String) {
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        if (sugDelLen > 0) ic.deleteSurroundingText(sugDelLen, 0)
        ic.commitText(s + " ", 1)
        ic.endBatchEdit()
        lastSpace = 0L
        lastCorr = null
        localWord.setLength(0)
        afterInput()
    }

    // ---------- ввод ----------

    private fun shifted(s: String) = if (shift > 0) s.uppercase() else s

    private val autoSeps = " .,!?;:)"
    private val skipBefore = "0123456789@#/\\_.:-'’=&%\$+<>"
    private val contractions = mapOf(
        "dont" to "don't", "cant" to "can't", "wont" to "won't", "didnt" to "didn't", "doesnt" to "doesn't",
        "isnt" to "isn't", "arent" to "aren't", "wasnt" to "wasn't", "werent" to "weren't", "couldnt" to "couldn't",
        "wouldnt" to "wouldn't", "shouldnt" to "shouldn't", "havent" to "haven't", "hasnt" to "hasn't",
        "hadnt" to "hadn't", "youre" to "you're", "theyre" to "they're", "thats" to "that's", "whats" to "what's",
        // частые опечатки, которые встречаются в словаре как «слова»
        "thier" to "their", "wich" to "which", "alot" to "a lot", "seperate" to "separate", "occured" to "occurred",
        "untill" to "until", "tommorow" to "tomorrow", "tomorow" to "tomorrow", "beleive" to "believe",
        "goverment" to "government", "truely" to "truly", "recieved" to "received"
    )

    private fun atSentenceStart(pre: String): Boolean {
        val t = pre.trimEnd(' ', '\t')
        return t.isEmpty() || ".!?…\n".indexOf(t.last()) >= 0
    }

    private fun applyCorr(ic: InputConnection, orig: String, fixed: String, sep: String) {
        ic.beginBatchEdit()
        ic.deleteSurroundingText(orig.length, 0)
        ic.commitText(fixed, 1)
        ic.endBatchEdit()
        lastCorr = Corr(orig, fixed, sep)
    }

    /** Вызывается перед пробелом / знаком препинания / Enter: исправляет слово слева от курсора. */
    private fun tryAutocorrect(ic: InputConnection, sep: String, allowLayout: Boolean) {
        lastCorr = null
        if (!autoOn || !dict.ready()) return
        val ei = currentInputEditorInfo ?: return
        if (!acAllowed(ei)) return
        val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: return

        // 1) слово набрано не в той раскладке («ghbdtn» -> «привет»), только по пробелу / Enter
        val tok = trailingToken(before)
        if (tok.length >= 3) {
            val fixedLayout = corr.layoutFix(tok)
            if (fixedLayout != null) {
                if (allowLayout) applyCorr(ic, tok, fixedLayout, sep)
                return
            }
        }

        // 2) опечатки
        val edWord = trailingWord(before)
        val loc = localWord.toString()
        val word = if (edWord.isNotEmpty() && loc.length > edWord.length && loc.length - edWord.length <= 2 && loc.startsWith(edWord)) loc else edWord
        if (word.length < 4 || word.length > 20) return
        val pre = before.substring(0, before.length - edWord.length)
        if (pre.isNotEmpty() && skipBefore.indexOf(pre.last()) >= 0) return
        if (word.all { it.isUpperCase() }) return
        val cyr = Layout.isCyr(word[0])
        if (!word.all { Layout.isCyr(it) == cyr && (cyr || it in 'a'..'z' || it in 'A'..'Z') }) return
        if (word[0].isUpperCase() && !atSentenceStart(pre)) return
        val low = word.lowercase()
        val lang = if (cyr) 0 else 1
        if (lang == 1) {
            val ct = contractions[low]
            if (ct != null) {
                applyCorr(ic, word, matchCase(word, ct), sep)
                return
            }
        }
        if (dict.known(lang, low)) return
        val fix = corr.fix(low, lang, !pal.lite) ?: return
        applyCorr(ic, word, matchCase(word, fix), sep)
    }

    private fun type(s: String) {
        val ic = currentInputConnection ?: return
        if (s.length == 1 && autoSeps.indexOf(s[0]) >= 0) {
            tryAutocorrect(ic, s, s == " ")
        } else {
            lastCorr = null
        }
        if (s.length == 1 && s[0].isLetter()) localWord.append(s) else localWord.setLength(0)
        if (s == " ") {
            // двойной пробел после слова = точка и пробел
            val now = System.currentTimeMillis()
            if (now - lastSpace < 500) {
                val b = ic.getTextBeforeCursor(2, 0)
                if (b != null && b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText(". ", 1)
                    lastSpace = 0L
                    lastCorr = null
                    afterInput()
                    return
                }
            }
            lastSpace = now
        }
        ic.commitText(s, 1)
        afterInput()
    }

    private fun backspace() {
        if (localWord.isNotEmpty()) localWord.setLength(localWord.length - 1)
        val lc = lastCorr
        lastCorr = null
        if (lc != null) {
            // Backspace сразу после автоисправления возвращает слово как было и запоминает его
            val ic = currentInputConnection
            val tail = lc.corrected + lc.sep
            val before = ic?.getTextBeforeCursor(tail.length, 0)?.toString()
            if (ic != null && before == tail) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(tail.length, 0)
                ic.commitText(lc.original, 1)
                ic.endBatchEdit()
                learnWord(lc.original.lowercase())
                localWord.setLength(0)
                afterInput()
                return
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        afterInput()
    }

    private fun enter() {
        val ei = currentInputEditorInfo
        val ic = currentInputConnection ?: return
        val act = if (ei == null) 0 else ei.imeOptions and EditorInfo.IME_MASK_ACTION
        val plain = ei == null ||
            (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            act == EditorInfo.IME_ACTION_NONE ||
            act == EditorInfo.IME_ACTION_UNSPECIFIED
        tryAutocorrect(ic, "\n", true)
        lastCorr = null
        localWord.setLength(0)
        if (plain) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) else ic.performEditorAction(act)
        afterInput()
    }

    private fun updateEnter() {
        val k = enterKey ?: return
        val ei = currentInputEditorInfo
        val multi = ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val act = if (ei == null) 0 else ei.imeOptions and EditorInfo.IME_MASK_ACTION
        val text: String? = if (multi) null else when (act) {
            EditorInfo.IME_ACTION_GO -> "Вперёд"
            EditorInfo.IME_ACTION_SEARCH -> "Поиск"
            EditorInfo.IME_ACTION_SEND -> "Отпр."
            EditorInfo.IME_ACTION_NEXT -> "Далее"
            EditorInfo.IME_ACTION_DONE -> "Готово"
            else -> null
        }
        if (text == null) {
            k.label = ""
            k.icon = ico(R.drawable.ic_enter)
        } else {
            k.icon = null
            k.label = text
        }
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == 2 -> 0
            shift == 1 && now - lastShiftTap < 350 -> 2   // двойное нажатие = Caps Lock
            shift == 1 -> 0
            else -> 1
        }
        lastShiftTap = now
        applyShift()
    }

    private fun afterInput() {
        autoCaps()
        updateSuggestions()
    }

    /** Автоматическая заглавная в начале предложения (как в Gboard). */
    private fun autoCaps() {
        if (shift == 2) return
        val ei = currentInputEditorInfo
        val caps = if (ei != null && ei.inputType != 0) {
            currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        } else 0
        val want = if (caps != 0) 1 else 0
        if (want != shift) {
            shift = want
            applyShift()
        }
    }

    private fun applyShift() {
        for (k in letterKeys) {
            val base = k.tag as String
            k.label = shifted(base)
            val a = ALT[base]
            k.hint = if (a != null) shifted(a) else null
        }
        shiftKey?.let {
            it.icon = ico(
                when (shift) {
                    0 -> R.drawable.ic_shift
                    1 -> R.drawable.ic_shift_on
                    else -> R.drawable.ic_caps
                }
            )
            it.active = shift > 0
        }
    }

    // ---------- буфер обмена ----------

    private fun captureClip() {
        try {
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            // Менеджеры паролей помечают секретное — такое не сохраняем
            if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
            val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
            if (text.isBlank()) return
            store.add(text)
            if (mode == 1) refreshClips()
        } catch (e: Exception) {
        }
    }

    private fun refreshClips() {
        val list = clipList ?: return
        list.removeAllViews()
        val items = store.all()
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = "Пока пусто.\nСкопируй текст — он появится здесь.\nНажми на карточку, чтобы вставить; ★ — закрепить."
            t.setTextColor(pal.hint)
            t.textSize = 14f
            t.setPadding(dp(16), dp(24), dp(16), 0)
            list.addView(t)
            return
        }
        for (item in items) {
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(dp(4), dp(3), dp(4), dp(3))
            list.addView(card(item), lp)
        }
    }

    private fun iconBtn(s: String, color: Int, action: () -> Unit): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 18f
        t.setTextColor(color)
        t.gravity = Gravity.CENTER
        t.setOnClickListener { action() }
        return t
    }

    private fun card(item: ClipStore.Item): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(10), dp(6), dp(10))
        val bg = GradientDrawable()
        bg.setColor(pal.keyA)
        bg.cornerRadius = dp(16).toFloat()
        row.background = bg
        row.setOnClickListener {
            currentInputConnection?.commitText(item.text, 1)
            setMode(0)
            afterInput()
        }

        val tv = TextView(this)
        tv.text = item.text.trim()
        tv.setTextColor(pal.text)
        tv.textSize = 15f
        tv.maxLines = 3
        tv.ellipsize = TextUtils.TruncateAt.END
        row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))

        row.addView(
            iconBtn(if (item.pinned) "★" else "☆", if (item.pinned) pal.accent else pal.hint) {
                store.togglePin(item.text)
                refreshClips()
            },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        row.addView(
            iconBtn("✕", pal.hint) {
                store.remove(item.text)
                refreshClips()
            },
            LinearLayout.LayoutParams(dp(40), dp(40))
        )
        return row
    }
}
