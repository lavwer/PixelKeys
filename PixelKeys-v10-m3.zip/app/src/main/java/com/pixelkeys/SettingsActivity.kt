package com.pixelkeys

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private val themes = listOf(
        "Авто (цвета обоев)", "Светлая", "Тёмная", "Серая", "Синяя",
        "Бирюзовая", "Зелёная", "Фиолетовая", "Розовая", "Оранжевая", "Свой цвет"
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var pal: Palette
    private lateinit var kbPal: Palette      // как выглядит сама клавиатура (с учётом фото)
    private var scroll: ScrollView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        prefs = getSharedPreferences("ui", MODE_PRIVATE)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return t
    }

    private fun lp(top: Int = 0, height: Int = LinearLayout.LayoutParams.WRAP_CONTENT): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height)
        p.topMargin = dp(top)
        return p
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(pal.container, 28)
        c.setPadding(dp(18), dp(8), dp(18), dp(8))
        return c
    }

    private fun section(title: String): TextView {
        // заголовки капсом приводим к обычному написанию, смешанный регистр («Стиль Material 3») оставляем как есть
        val shown = if (title == title.uppercase()) title.lowercase().replaceFirstChar { it.uppercase() } else title
        val t = tv(shown, 14f, pal.accent, true)
        t.setPadding(dp(8), dp(24), 0, dp(8))
        return t
    }

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(pal.line)
        return v
    }

    private fun pill(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val t = tv(text, 16f, if (filled) pal.onAction else pal.text, true)
        t.gravity = Gravity.CENTER
        t.background = round(if (filled) pal.action else pal.tonal, 26)
        t.setPadding(dp(16), 0, dp(16), 0)
        t.setOnClickListener { onClick() }
        ripple(t, 26)
        return t
    }

    /** Смещает оттенок цвета: из любого цвета темы получается красивый двухцветный градиент. */
    private fun shiftHue(color: Int, deg: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[0] = (hsv[0] + deg) % 360f
        hsv[1] = (hsv[1] * 1.1f).coerceAtMost(1f)
        return Color.HSVToColor(hsv)
    }

    private fun gradient(c1: Int, c2: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun heroButton(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = tv(text, 16f, if (primary) pal.action else pal.onAction, true)
        t.gravity = Gravity.CENTER
        t.background = round(if (primary) pal.onAction else ((pal.onAction and 0x00FFFFFF) or (0x26 shl 24)), 28)
        t.setPadding(dp(16), 0, dp(16), 0)
        t.setOnClickListener { onClick() }
        ripple(t, 28)
        return t
    }

    private fun chip(text: String): TextView {
        val t = tv(text, 12f, pal.text, true)
        t.background = round(pal.tonal, 14)
        t.setPadding(dp(12), dp(5), dp(12), dp(5))
        return t
    }

    private fun featureCard(emoji: String, title: String, desc: String): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(pal.container, 26)
        c.setPadding(dp(16), dp(16), dp(16), dp(18))
        val badge = tv(emoji, 22f, pal.text)
        badge.gravity = Gravity.CENTER
        badge.background = round(pal.tonal, 16)
        c.addView(badge, LinearLayout.LayoutParams(dp(46), dp(46)))
        val t = tv(title, 16f, pal.text, true)
        t.setPadding(0, dp(12), 0, dp(4))
        c.addView(t)
        c.addView(tv(desc, 13f, pal.hint))
        return c
    }

    private fun featureRow(a: View, b: View): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        val la = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        la.rightMargin = dp(5)
        val lb = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        lb.leftMargin = dp(5)
        r.addView(a, la)
        r.addView(b, lb)
        return r
    }

    private fun stepRow(n: Int, text: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        val num = tv(n.toString(), 16f, pal.onAction, true)
        num.gravity = Gravity.CENTER
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(pal.action)
        num.background = oval
        r.addView(num, LinearLayout.LayoutParams(dp(36), dp(36)))
        val t = tv(text, 15f, pal.text)
        t.setPadding(dp(14), 0, 0, 0)
        r.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return r
    }

    private fun choiceRow(title: String, key: String, names: List<String>, def: Int): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(14), 0, dp(14))
        ripple(r, 12)
        r.addView(tv(title, 16f, pal.text), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(tv(names[prefs.getInt(key, def).coerceIn(0, names.size - 1)], 15f, pal.accent, true))
        r.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(names.toTypedArray()) { _, which ->
                    prefs.edit().putInt(key, which).apply()
                    render()
                }
                .show()
        }
        return r
    }

    private fun switchRow(title: String, sub: String, key: String, def: Int, onWhen: Int): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        ripple(r, 12)
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tv(title, 16f, pal.text))
        left.addView(tv(sub, 13f, pal.hint))
        r.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getInt(key, def) == onWhen
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(pal.onAction, pal.hint))
        sw.trackTintList = ColorStateList(states, intArrayOf(pal.action, pal.line))
        sw.setOnCheckedChangeListener { _, c ->
            prefs.edit().putInt(key, if (c) onWhen else 1 - onWhen).apply()
        }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        return r
    }

    /** Волна при нажатии (как в Material 3): ограничена скруглённой формой элемента. */
    private fun ripple(v: View, radiusDp: Int) {
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE)
        mask.cornerRadius = dp(radiusDp).toFloat()
        val tint = (pal.text and 0x00FFFFFF) or (0x1F shl 24)
        v.foreground = RippleDrawable(ColorStateList.valueOf(tint), null, mask)
    }

    private fun roundClip(v: View, radiusDp: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
            }
        }
        v.clipToOutline = true
    }

    /** Мини-клавиатура: показывает выбранную тему, фон-фото, скругление, прозрачность и размер букв. */
    private fun previewCard(): View {
        val kb = kbPal
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        val photo = if (kb.hasPhoto) BgStore.load(this) else null
        if (photo != null) {
            outer.background = CropDrawable(photo)
            roundClip(outer, 28)
        } else {
            val bg = round(kb.bg, 28)
            bg.setStroke(dp(2), kb.pressed)
            outer.background = bg
        }
        outer.setPadding(dp(8), dp(10), dp(8), dp(10))

        val cap = LinearLayout(this)
        cap.orientation = LinearLayout.HORIZONTAL
        cap.gravity = Gravity.CENTER
        cap.background = round(kb.keyA, 20)
        for (w in listOf("привет", "прикольно", "приятно")) {
            val t = tv(w, 14f, kb.text)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            cap.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        }
        val capLp = lp(0, dp(34))
        capLp.setMargins(dp(4), 0, dp(4), dp(4))
        outer.addView(cap, capLp)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        for (ch in "приветик") {
            val k = Key(this, kb, Key.NORMAL)
            k.label = ch.toString()
            k.haptic = false
            row1.addView(k, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        }
        outer.addView(row1, lp(0, dp(46)))

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val k1 = Key(this, kb, Key.SPECIAL)
        k1.label = "?123"
        k1.textSp = 15f
        k1.haptic = false
        val k2 = Key(this, kb, Key.NORMAL)
        k2.label = "Русский"
        k2.textSp = 13f
        k2.haptic = false
        val k3 = Key(this, kb, Key.ACTION)
        k3.scallop = true
        k3.icon = getDrawable(R.drawable.ic_enter)?.mutate()
        k3.haptic = false
        row2.addView(k1, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.6f))
        row2.addView(k2, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 4f))
        row2.addView(k3, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.8f))
        outer.addView(row2, lp(0, dp(46)))
        return outer
    }

    /** Строка с ползунком. Значение сохраняется, когда отпустишь палец. */
    private fun sliderRow(title: String, key: String, min: Int, max: Int, def: Int, unit: String, onDone: (() -> Unit)? = null): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(12), 0, dp(6))
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(tv(title, 16f, pal.text), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val valueTv = tv("", 15f, pal.accent, true)
        head.addView(valueTv)
        box.addView(head)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = prefs.getInt(key, def).coerceIn(min, max) - min
        valueTv.text = (sb.progress + min).toString() + unit
        sb.progressTintList = ColorStateList.valueOf(pal.accent)
        sb.thumbTintList = ColorStateList.valueOf(pal.accent)
        sb.progressBackgroundTintList = ColorStateList.valueOf(pal.tonal)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                valueTv.text = (progress + min).toString() + unit
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {
                prefs.edit().putInt(key, (bar?.progress ?: 0) + min).apply()
                if (onDone != null) onDone() else render()
            }
        })
        box.addView(sb, lp(4))
        return box
    }

    // ---------- фон из фото ----------

    private val reqPhoto = 41

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Выбери фото для фона"), reqPhoto)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPhoto || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Обрабатываю фото…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = BgStore.importPhoto(this, uri) &&
                BgStore.process(this, prefs.getInt("bgblur", 40), prefs.getInt("bgdim", 30))
            runOnUiThread {
                if (!ok) Toast.makeText(this, "Не удалось открыть фото", Toast.LENGTH_SHORT).show()
                render()
            }
        }.start()
    }

    private fun reprocess() {
        Toast.makeText(this, "Применяю…", Toast.LENGTH_SHORT).show()
        Thread {
            BgStore.process(this, prefs.getInt("bgblur", 40), prefs.getInt("bgdim", 30))
            runOnUiThread { render() }
        }.start()
    }

    private fun render() {
        val oldY = scroll?.scrollY ?: 0
        pal = Palette(this, prefs.getInt("theme", 0), true)
        kbPal = Palette(this, prefs.getInt("theme", 0))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(40))

        // --- шапка сайта: логотип, название, версия ---
        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            ""
        }
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        try {
            logo.setImageDrawable(packageManager.getApplicationIcon(packageName))
        } catch (e: Exception) {
        }
        nav.addView(logo, LinearLayout.LayoutParams(dp(40), dp(40)))
        val brand = tv("Pixel Keys", 20f, pal.text, true)
        brand.setPadding(dp(12), 0, 0, 0)
        nav.addView(brand, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        nav.addView(chip("v$ver"))
        root.addView(nav, lp(0, dp(48)))

        // --- главный блок (hero) ---
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.background = round(pal.action, 28)
        hero.setPadding(dp(22), dp(26), dp(22), dp(22))
        hero.addView(tv("Клавиатура", 14f, pal.onAction, true))
        val h1 = tv("Печатай быстро.\nНикому не доверяй пароли.", 30f, pal.onAction, true)
        h1.setPadding(0, dp(6), 0, dp(10))
        hero.addView(h1)
        hero.addView(tv("Умный T9, автоисправление, буфер обмена и 11 тем. Без доступа в интернет: набранное остаётся на телефоне.", 15f, pal.onAction))
        hero.addView(heroButton("Включить клавиатуру", true) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp(22, dp(54)))
        hero.addView(heroButton("Выбрать Pixel Keys", false) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, lp(10, dp(54)))
        hero.addView(previewCard(), lp(20))
        root.addView(hero, lp(16))

        // --- оптимизация одной кнопкой ---
        val lite = prefs.getInt("lite", 0) == 1
        val copt = card()
        copt.addView(tv(if (lite) "Лёгкий режим включён" else "Оптимизация", 16f, pal.text, true).apply { setPadding(0, dp(10), 0, dp(2)) })
        copt.addView(tv("Одна кнопка отключает анимации, эффекты и увеличенную букву, а подсказки считаются легче: без поиска опечаток в T9 и глубокой проверки автоисправления. Для слабых телефонов и экономии батареи. Твои настройки не стираются: выключишь режим, и всё вернётся.", 13f, pal.hint).apply { setPadding(0, 0, 0, dp(6)) })
        copt.addView(pill(if (lite) "Выключить лёгкий режим" else "Оптимизировать", !lite) {
            prefs.edit().putInt("lite", if (lite) 0 else 1).apply()
            render()
        }, lp(8, dp(50)))
        root.addView(copt, lp(14))

        // --- возможности ---
        root.addView(section("ВОЗМОЖНОСТИ"))
        root.addView(featureRow(
            featureCard("🔒", "Без интернета", "В приложении нет разрешения на сеть. Отправить нечего и некуда."),
            featureCard("✨", "Умный T9", "Подсказки и автоисправление, в том числе при неверной раскладке.")
        ), lp())
        root.addView(featureRow(
            featureCard("📋", "Буфер обмена", "История копирования с закреплением. Секретное не сохраняется."),
            featureCard("🎨", "11 тем", "Цвета из обоев Pixel или свои: серая, синяя, зелёная и другие.")
        ), lp(10))

        // --- как подключить ---
        root.addView(section("КАК ПОДКЛЮЧИТЬ"))
        val steps = card()
        steps.addView(stepRow(1, "Нажми «Включить клавиатуру» и включи Pixel Keys в списке"))
        steps.addView(divider(), lp(0, dp(1)))
        steps.addView(stepRow(2, "Нажми «Выбрать Pixel Keys» и укажи её основной"))
        steps.addView(divider(), lp(0, dp(1)))
        steps.addView(stepRow(3, "Проверь набор в поле ниже"))
        root.addView(steps, lp())

        root.addView(section("ПОПРОБУЙ ПРЯМО ЗДЕСЬ"))
        val field = EditText(this)
        field.hint = "Нажми сюда и напиши что-нибудь"
        field.setTextColor(pal.text)
        field.setHintTextColor(pal.hint)
        field.background = round(pal.container, 22)
        field.setPadding(dp(18), dp(16), dp(18), dp(16))
        root.addView(field, lp())

        root.addView(section("ВНЕШНИЙ ВИД"))
        val c1 = card()
        c1.addView(choiceRow("Тема", "theme", themes, 0))
        if (prefs.getInt("theme", 0) == 10) {
            c1.addView(divider(), lp(0, dp(1)))
            c1.addView(sliderRow("Оттенок", "hue", 0, 359, 210, "°"))
            c1.addView(divider(), lp(0, dp(1)))
            c1.addView(sliderRow("Насыщенность", "sat", 20, 100, 100, "%"))
        }
        c1.addView(divider(), lp(0, dp(1)))
        c1.addView(choiceRow("Высота клавиш", "height", listOf("Низкая", "Средняя", "Высокая"), 1))
        c1.addView(divider(), lp(0, dp(1)))
        c1.addView(choiceRow("Ряд цифр", "numrow", listOf("Всегда", "Только вертикально", "Скрыть"), 1))
        root.addView(c1, lp())

        // --- фон из фото ---
        root.addView(section("ФОН КЛАВИАТУРЫ"))
        val cbg = card()
        val hasPhoto = BgStore.exists(this)
        if (hasPhoto) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(BgStore.load(this))
            roundClip(iv, 20)
            cbg.addView(iv, lp(12, dp(130)))
        } else {
            val hintTv = tv("Поставь своё фото на фон клавиатуры. Фото берётся из галереи и хранится только на телефоне.", 14f, pal.hint)
            hintTv.setPadding(0, dp(14), 0, dp(6))
            cbg.addView(hintTv)
        }
        cbg.addView(pill(if (hasPhoto) "Выбрать другое фото" else "Выбрать фото", true) { pickPhoto() }, lp(12, dp(50)))
        if (hasPhoto) {
            cbg.addView(sliderRow("Размытие", "bgblur", 0, 100, 40, "%") { reprocess() })
            cbg.addView(divider(), lp(0, dp(1)))
            cbg.addView(sliderRow("Затемнение", "bgdim", 0, 80, 30, "%") { reprocess() })
            cbg.addView(pill("Убрать фото", false) {
                BgStore.clear(this)
                render()
            }, lp(10, dp(50)))
        }
        root.addView(cbg, lp())

        // --- форма и размер клавиш ---
        root.addView(section("ФОРМА И РАЗМЕР КЛАВИШ"))
        val cshape = card()
        cshape.addView(sliderRow("Скругление клавиш", "radius", 0, 100, 50, "%"))
        cshape.addView(divider(), lp(0, dp(1)))
        cshape.addView(sliderRow("Прозрачность клавиш", "keyalpha", 30, 100, 100, "%"))
        cshape.addView(divider(), lp(0, dp(1)))
        cshape.addView(sliderRow("Размер букв", "textsize", 70, 140, 100, "%"))
        cshape.addView(divider(), lp(0, dp(1)))
        cshape.addView(sliderRow("Расстояние между клавишами", "gap", 0, 8, 3, " dp"))
        root.addView(cshape, lp())

        // --- кастом в стиле ма3 ---
        root.addView(section("Стиль Material 3"))
        val cm3 = card()
        cm3.addView(choiceRow("Форма служебных клавиш", "shape", listOf("Волнистая", "Скруглённая", "Капсула"), 0))
        cm3.addView(divider(), lp(0, dp(1)))
        cm3.addView(choiceRow("Начертание букв", "font", listOf("Обычное", "Среднее", "Жирное"), 0))
        cm3.addView(divider(), lp(0, dp(1)))
        cm3.addView(switchRow("Анимация нажатия", "Клавиша на миг становится капсулой", "morph", 0, 0))
        cm3.addView(divider(), lp(0, dp(1)))
        cm3.addView(switchRow("Подсказки на клавишах", "Мелкие символы в углу: ё, ъ, ?, !", "hints", 0, 0))
        cm3.addView(divider(), lp(0, dp(1)))
        cm3.addView(switchRow("Увеличенная буква", "Показывать над клавишей при нажатии", "bubble", 0, 0))
        cm3.addView(divider(), lp(0, dp(1)))
        cm3.addView(sliderRow("Отступ снизу", "bpad", 0, 32, 8, " dp"))
        cm3.addView(divider(), lp(0, dp(1)))
        cm3.addView(sliderRow("Отступы по бокам", "hpad", 0, 16, 4, " dp"))
        root.addView(cm3, lp())

        // --- эффекты после нажатия ---
        root.addView(section("Эффекты нажатия"))
        val cfx2 = card()
        cfx2.addView(switchRow("Эффекты при нажатии", "Короткая анимация внутри клавиши после касания", "fxon", 1, 0))
        cfx2.addView(divider(), lp(0, dp(1)))
        cfx2.addView(choiceRow("Эффект", "fx", listOf("Волна", "Кольцо", "Свечение", "Пиксели", "Искры"), 0))
        cfx2.addView(tv("Нажми на клавиши мини-клавиатуры вверху, чтобы посмотреть эффект. В лёгком режиме эффекты выключены.", 13f, pal.hint).apply { setPadding(0, dp(4), 0, dp(10)) })
        root.addView(cfx2, lp())

        root.addView(section("ОТКЛИК"))
        val cfx = card()
        cfx.addView(switchRow("Вибрация", "Лёгкий отклик при нажатии", "vibrate", 0, 0))
        cfx.addView(divider(), lp(0, dp(1)))
        cfx.addView(switchRow("Звук клавиш", "Работает, если в системе включены звуки нажатий", "sound", 1, 0))
        root.addView(cfx, lp())
        root.addView(pill("Сбросить оформление", false) {
            val e = prefs.edit()
            for (k in listOf("radius", "keyalpha", "textsize", "gap", "bgblur", "bgdim", "vibrate", "sound",
                "font", "shape", "morph", "hints", "bubble", "bpad", "hpad", "hue", "sat", "fxon", "fx")) e.remove(k)
            e.apply()
            BgStore.clear(this)
            render()
        }, lp(12, dp(50)))

        root.addView(section("РАСКЛАДКА"))
        val c2 = card()
        c2.addView(switchRow("Только буквы", "Без цифр, запятой, точки и глобуса", "minimal", 0, 1))
        c2.addView(divider(), lp(0, dp(1)))
        c2.addView(switchRow("Запятая и точка", "Кнопки в нижнем ряду", "punct", 0, 0))
        root.addView(c2, lp())

        root.addView(section("ВВОД"))
        val c3 = card()
        c3.addView(switchRow("Подсказки слов (T9)", "Три слова над клавиатурой", "t9", 0, 0))
        c3.addView(divider(), lp(0, dp(1)))
        c3.addView(switchRow("Автоисправление", "Опечатки и слова не в той раскладке", "autocorr", 0, 0))
        c3.addView(divider(), lp(0, dp(1)))
        c3.addView(switchRow("Исправлять везде", "Даже там, где приложение просит не править текст", "autoany", 0, 0))
        root.addView(c3, lp())

        root.addView(section("ДАННЫЕ"))
        root.addView(pill("Очистить историю буфера", false) {
            ClipStore(this).clearAll()
            Toast.makeText(this, "История очищена", Toast.LENGTH_SHORT).show()
        }, lp(0, dp(52)))
        root.addView(pill("Забыть выученные слова", false) {
            prefs.edit().remove("userwords").apply()
            Toast.makeText(this, "Готово", Toast.LENGTH_SHORT).show()
        }, lp(10, dp(52)))

        root.addView(section("ДИАГНОСТИКА"))
        val c5 = card()
        val diag = (prefs.getString("diag", "") ?: "").split("\n").filter { it.isNotBlank() }
        c5.addView(tv("В каких приложениях работают подсказки и автоисправление. Откройте клавиатуру в нужном приложении и вернитесь сюда.", 13f, pal.hint).apply { setPadding(0, dp(10), 0, dp(6)) })
        if (diag.isEmpty()) {
            c5.addView(tv("Пока пусто.", 14f, pal.text).apply { setPadding(0, dp(4), 0, dp(10)) })
        } else {
            for (d in diag) {
                c5.addView(tv(d.replace(" | ", "\n"), 12f, pal.text).apply { setPadding(0, dp(8), 0, dp(8)) })
                c5.addView(divider(), lp(0, dp(1)))
            }
        }
        root.addView(c5, lp())
        root.addView(pill("Обновить список", false) { render() }, lp(10, dp(52)))

        root.addView(section("ПРИВАТНОСТЬ"))
        val c4 = card()
        val perms = try {
            packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS).requestedPermissions
        } catch (e: Exception) {
            null
        }
        val net = perms?.contains("android.permission.INTERNET") == true
        val status = tv(
            if (net) "⚠ Приложение запрашивает доступ в интернет"
            else "✔ Доступа в интернет нет: клавиатура физически не может ничего отправить наружу.",
            15f, pal.accent, true
        )
        status.setPadding(0, dp(12), 0, dp(6))
        c4.addView(status)
        val note = tv(
            "Скопированные тексты хранятся только на этом телефоне и удаляются через 24 часа (закреплённые остаются). " +
                "Тексты, которые менеджер паролей пометил как секретные, не записываются. " +
                "В полях паролей, почты и адресов подсказки и автоисправление выключены.",
            13f, pal.hint
        )
        note.setPadding(0, 0, 0, dp(12))
        c4.addView(note)
        root.addView(c4, lp())

        val foot = tv("Pixel Keys · версия $ver", 13f, pal.hint, true)
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, dp(30), 0, dp(4))
        root.addView(foot)
        val foot2 = tv("Сделано так, чтобы набранный текст никуда не уходил.", 12f, pal.hint)
        foot2.gravity = Gravity.CENTER
        root.addView(foot2)

        val sv = ScrollView(this)
        sv.setBackgroundColor(pal.surface)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(root)
        setContentView(sv)
        scroll = sv
        if (oldY > 0) sv.post { sv.scrollTo(0, oldY) }
        applyBars()
    }

    @Suppress("DEPRECATION")
    private fun applyBars() {
        window.statusBarColor = pal.surface
        window.navigationBarColor = pal.surface
        val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val f = window.decorView.systemUiVisibility
        window.decorView.systemUiVisibility = if (pal.night) f and light.inv() else f or light
    }
}
